﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLibraryEF
{
    public class ActualDal : IDal
    {
        public List<employee> GetAllEmployees()
        {
            using (DacWondersEntities dacWondersEntities = new DacWondersEntities())
            {
                List<employee> lst = (from emp in dacWondersEntities.employees select emp).ToList();
                return lst;
            }
        }

        public void AddEmployee(employee emp)
        {
            using(DacWondersEntities dacWondersEntities = new DacWondersEntities())
            {
                dacWondersEntities.employees.Add(emp);
                dacWondersEntities.SaveChanges();
            }
        }

        public void ModifyEmployee(employee empToBeModified)
        {
            using (DacWondersEntities dacWondersEntities = new DacWondersEntities())
            {
                var empselected = (from emp in dacWondersEntities.employees where emp.EID == empToBeModified.EID select emp).First();
                empselected.EName = empToBeModified.EName;
                empselected.DEPT = empToBeModified.DEPT;
                dacWondersEntities.SaveChanges();
            }
        }

        public void DeleteEmployee(int id)
        {
            using(DacWondersEntities dacWondersEntities = new DacWondersEntities())
            {
                var empselected = (from emp in dacWondersEntities.employees where emp.EID == id select emp).First();
                dacWondersEntities.employees.Remove(empselected);
                dacWondersEntities.SaveChanges();
            }
        }
    }
}
