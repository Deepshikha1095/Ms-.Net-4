﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLibraryEF
{
    public class FakeDal : IDal
    {
        static List<employee> empList = new List<employee>();
        public FakeDal()
        {
            empList.Add(new employee { EID = 101, EName = "John", DEPT = 502 });
            empList.Add(new employee { EID = 102, EName = "Doe  ", DEPT = 501 });
            empList.Add(new employee { EID = 103, EName = "Jane", DEPT = 502 });
            empList.Add(new employee { EID = 104, EName = "Smith", DEPT = 501 });
            empList.Add(new employee { EID = 105, EName = "Zack", DEPT = 505 });
        }
        public void AddEmployee(employee emp)
        {
            empList.Add(emp);
        }

        public void DeleteEmployee(int id)
        {
            var emp = empList.Where(e => e.EID == id).FirstOrDefault();
            empList.Remove(emp);
        }

        public List<employee> GetAllEmployees()
        {
            return empList;
        }

        public void ModifyEmployee(employee empToBeModified)
        {
            var emp = empList.Where(e => e.EID ==  empToBeModified.EID).FirstOrDefault();
            emp.EName = empToBeModified.EName;
            emp.DEPT = empToBeModified.DEPT;
        }
    }
}
