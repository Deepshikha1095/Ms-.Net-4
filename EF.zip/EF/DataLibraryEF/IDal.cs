﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLibraryEF
{
    public interface IDal
    {
        List<employee> GetAllEmployees();
        void AddEmployee(employee emp);
        void ModifyEmployee(employee empToBeModified);
        void DeleteEmployee(int id);
    }
}
