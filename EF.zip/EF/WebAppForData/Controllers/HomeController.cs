﻿using DataLibraryEF;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Ninject;
using System.Configuration;

namespace WebAppForData.Controllers
{
    public class HomeController : Controller
    {
        private readonly IDal dalAccess;
        public HomeController()
        {
            IKernel kernel = new StandardKernel();
            string repoType = ConfigurationManager.AppSettings["repoName"];
            Type type = Type.GetType($"DataLibraryEF.{repoType},DataLibraryEF");
            kernel.Bind<IDal>().To(type);
            dalAccess = kernel.Get<IDal>();
        }
        public ActionResult Index()
        {
            return View(dalAccess.GetAllEmployees());
        }

        public ActionResult AddEmployee()
        {
            return View(new employee());
        }
        [HttpPost]
        public ActionResult AddEmployee(employee emp)
        {
            dalAccess.AddEmployee(emp);
            return RedirectToAction("Index");
        }

        public ActionResult RemoveEmployee(int id)
        {
            dalAccess.DeleteEmployee(id);
            return RedirectToAction("Index");
        }

        public ActionResult EditEmployee(int id)
        {
            var emp = (from em in dalAccess.GetAllEmployees() where em.EID == id select em).FirstOrDefault();
            return View(emp);
        }

        [HttpPost]
        public ActionResult EditEmployee(employee emp)
        {
            dalAccess.ModifyEmployee(emp);
            return RedirectToAction("Index");
        }
    }
}